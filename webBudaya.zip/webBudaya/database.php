<?php
require('session.php');
require('koneksi.php');
    $queryKategori = "SELECT * FROM kategori";
    $resultKategori = mysqli_query($con,$queryKategori);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Admin</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 720px;
            overflow: auto;
        }
    </style>
</head>
<body class="container">
        <div id="adminNav">
            <div class="brand">
                <h3><a href="home.php">Web Budaya</a></h3>
            </div>
            <ul>
                <li><a href="database.php">Tampil Database</a></li>
                <li><a href="tambah.php">Tambah Data</a></li>
                <li><a href="hapus.php">Hapus Data</a></li>
                <li><a href="edit.php">Edit Data</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
        <div class="menu">Selamat Datang, Admin!</div>
        <div class="wrapForm">
        <p class="teks">Kelola Database Anda</p>
        <form id="form" action="" method="post" enctype="multipart/form-data">
            <select name="pilih">
                <?php
                    if (mysqli_num_rows($resultKategori) > 0) {
                        while($data = mysqli_fetch_assoc($resultKategori)) {
                            echo "<option value='$data[id]'>".$data['nama']."</option>";
                        }
                    }
                ?>
            </select>
            <button name="select">Pilih</button>
        </form>
        <?php
            if (isset($_POST['select'])) {
                $idKategori = $_POST['pilih'];
                
                echo "<table class='tampil'>";
                echo 
                    "<tr>
                        <th>id.</th>
                        <th>Nama Data</th>";
                    echo "<th>Gambar</th>
                        <th>Deskripsi</th>
                    </tr>";

                $querySelect = "SELECT * FROM budaya WHERE id_kategori=$idKategori";
                $result = mysqli_query($con, $querySelect);
                if(mysqli_num_rows($result) > 0) {
                    while($data = mysqli_fetch_assoc($result)) {
                        echo
                        "<tr>
                            <td>".$data['id']."</td>
                            <td>".$data['nama']."</td>
                            <td><img src='".$data['gambar']."' height='60px' width='100px'>
                            <td>".$data['deskripsi']."</td>
                        </tr>";
                    }
                }
                else {
                    echo "<tr>
                            <td colspan='4' align='center'>Tidak Ada Data Untuk Ditampilkan</td>
                        </tr>";
                }
                echo "</table>";
            }
        ?>
        </div>
      
</body>
</html>