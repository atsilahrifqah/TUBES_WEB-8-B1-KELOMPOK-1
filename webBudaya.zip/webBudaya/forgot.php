<?php
require('koneksi.php');

function forgot($data)
{
    global $con;
    $username = strtoupper($data["username"]);
    $password = $data["password"];

    //cek username
    $queryUsername = "SELECT username FROM users WHERE username = '$username'";
    $result = mysqli_query($con, $queryUsername);
    if (mysqli_fetch_assoc($result) == 0) {
        echo '<script>
                alert("username tidak terdaftar");
            </script>';
        return false;
    }

    //enkripsi password
    $password = password_hash($password, PASSWORD_DEFAULT);

    //update password ke database
    $queryUpdate = "UPDATE users SET password='$password' WHERE username='$username'";
    mysqli_query($con, $queryUpdate);

    return mysqli_affected_rows($con);
}
