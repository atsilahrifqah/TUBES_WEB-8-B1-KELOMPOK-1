<?php
require("session.php");
require("koneksi.php");

if (isset($_POST['tambah'])) {
   $idKategori = $_POST['pilih'];
   $nama = $_POST['nama'];
   $desk =$_POST['deskripsi'];

   $direktori = "berkas/";
   $fileGambar = $_FILES['gambar']['name'];
   move_uploaded_file($_FILES['gambar']['tmp_name'],$direktori.$fileGambar);

   $queryInsert = "INSERT INTO budaya VALUES ('',$idKategori,'$nama','$fileGambar','$desk')";
   $result = mysqli_query($con,$queryInsert);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Tambah Data</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 720px;
            overflow: auto;
        }
    </style>
</head>
<body class="container">
        <div id="adminNav">
            <div class="brand">
                <h3><a href="home.php">Web Budaya</a></h3>
            </div>
            <ul>
                <li><a href="database.php">Tampil Database</a></li>
                <li><a href="tambah.php">Tambah Data</a></li>
                <li><a href="hapus.php">Hapus Data</a></li>
                <li><a href="edit.php">Edit Data</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
        <div class="menu">Tambah Data Ke Web</div>
        <div class="wrapForm">
        <p class="teks">Pilih Kategori Dari Data yang Ingin Ditambahkan</p>
        <form id="form" action="" method="post" enctype="multipart/form-data">
            <select name="pilih" placeholder="pilih database tujuan">
                <?php
                    $queryKategori = "SELECT * FROM kategori";
                    $resultKategori = mysqli_query($con,$queryKategori);

                    if (mysqli_num_rows($resultKategori) > 0) {
                        while($data = mysqli_fetch_assoc($resultKategori)) {
                            echo "<option value='$data[id]'>".$data['nama']."</option>";
                        }
                    }
                ?>
            </select><br>
            <div class="input">
                <label>Nama</label><br>
                <input type="text" name="nama" size="25" autocomplete="off" placeholder="masukkan nama data baru" required><br>
                <label>Deskripsi</label><br>
                <textarea type="text" name="deskripsi" rows="7" cols="50px" placeholder="masukkan deskripsi" autocomplete="off" required></textarea><br>
                <label>File Gambar</label><br>
                <input type="file" name="gambar" required><br>
                <input type="submit" name="tambah" value="tambah data">
            </div>
            <?php
                if (isset($result)) {
                    echo '<div class="ditambah">
                          Data Berhasil Ditambahkan.
                          </div>';
                 }
            ?>
        </form>
        </div>
    
</body>
</html>