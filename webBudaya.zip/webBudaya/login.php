<?php
session_start();
require('koneksi.php');

if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    //cek admin
    $queryAdmin = "SELECT * FROM users WHERE username='admin'";
    $resultAdmin = mysqli_query($con, $queryAdmin);

    if (mysqli_num_rows($resultAdmin) > 0) { //cek username
        while ($data = mysqli_fetch_assoc($resultAdmin)) {
            if ($password === $data["password"]) { //cek password
                $_SESSION["login"] = true;
                header("location:http://localhost/webbudaya/database.php");
                exit;
            }
        }
    }

    //cek user
    $queryUsername = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($con, $queryUsername);

    if (mysqli_num_rows($result) > 0) { //cek username
        while ($data = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $data["password"])) { //cek password
                $_SESSION["login"] = true;
                header("location:http://localhost/webbudaya/home.php?username=$data[username]");
                exit;
            }
        }
    }

    //username/password salah atau tidak tersedia
    $userSalah = true;
    if (isset($userSalah)) {
        echo "<p id='error'>Username atau Password Anda Salah <br> Pastikan Anda Telah Terdaftar</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Login</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <style>
        .container {
            height: 720px;
        }

        #welcome {
            top: 150px;
            color: white;
        }
    </style>
</head>

<body class="container">
    <nav>
        <div class="brand">
            <h3><a href="home.php">Web Budaya</a></h3>
        </div>
        <ul>
            <li><a href="login.php">Login</a></li>
            <li><a href="daftar.php">Daftar</a></li>
        </ul>
    </nav>
    <h2 id="welcome">Halaman Login</h2>
    <table class="login" align="center" cellspacing="11">
        <form action="" method="post">
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>Username</td>
                <td><input type="text" name="username" placeholder="username" autocomplete="off" required></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>Password</td>
                <td><input type="password" name="password" placeholder="password" autocomplete="off" required></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="login" value="LOGIN" style="cursor: pointer;">
                </td>
            </tr>
        </form>
    </table>
    <a href="">lupa password?</a>
    <h4 id="belum"><a href="lupa.php">lupa password?</a><br><br>
        Belum punya akun? <a href="daftar.php">Daftar</a></h4>

</body>

</html>