<?php
require("koneksi.php");

$id = $_GET["id"];

$query = "SELECT * FROM budaya WHERE id=$id";
$result = mysqli_query($con, $query);


if (isset($_POST['edit'])) {
    $nama = $_POST['nama'];
    $desk =$_POST['deskripsi'];
 
    $direktori = "berkas/";
    $fileGambar = $_FILES['gambar']['name'];
    move_uploaded_file($_FILES['gambar']['tmp_name'],$direktori.$fileGambar);
 
    $queryUpdate = "UPDATE budaya SET nama='$nama', deskripsi='$desk', gambar='$fileGambar' WHERE id=$id";
    $resultUpdate = mysqli_query($con,$queryUpdate);
 }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Tarian Adat</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 720px;
            overflow: hidden;
        }
        #form{
            top: -30px;
        }
    </style>
</head>
<body class="container">
        <div id="adminNav">
            <div class="brand">
                <h3><a href="home.php">Web Budaya</a></h3>
            </div>
            <ul>
                <li><a href="database.php">Tampil Database</a></li>
                <li><a href="tambah.php">Tambah Data</a></li>
                <li><a href="hapus.php">Hapus Data</a></li>
                <li><a href="edit.php">Edit Data</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
        <div class="menu">Edit Data Web</div>
        </div>
        <div class="wrapForm">
        <?php
            if (mysqli_num_rows($result)>0) {
                while($data = mysqli_fetch_assoc($result)) {
                    echo '
                    <form id="form" action="" method="post" enctype="multipart/form-data">
                    <div class="input">
                    <label>Nama</label><br>
                    <input type="text" name="nama" size="25" autocomplete="off" value="'.$data['nama'].'" required><br>
                    <label>Deskripsi</label><br>
                    <textarea type="text" name="deskripsi" rows="7" cols="50px" autocomplete="off" required>'.$data['deskripsi'].'</textarea><br>
                    <label>File Gambar</label><br>
                    <input type="file" name="gambar" value='.$data['gambar'].'required><br>
                    <input type="submit" name="edit" value="edit data">
                    </div>';
                }
            }
            if (isset($resultUpdate)) {
                    echo '<div class="ditambah">
                        Data Berhasil Diedit.
                        </div>';
            }
     ?>
</form>
        </div>
        <div class="footerAdmin">
            Alfian Diva Awangga, Pemrograman Web 2, 2023
        </div>
</body>
</html>