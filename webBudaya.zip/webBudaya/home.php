<?php
require("session.php");
require("koneksi.php");

$username = $_GET['username'];
$queryUser = "SELECT * FROM users WHERE username='$username'";
$resultUser = mysqli_query($con, $queryUser);

$queryKategori = "SELECT * FROM kategori";
$resultKategori = mysqli_query($con, $queryKategori);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Home</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <style>
        .container {
            height: 1400px;
        }
    </style>
</head>

<body class="container">
    <nav>
        <div class="brand">
            <h3><a href="home.php">Web Budaya</a></h3>
        </div>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li>
                <a href="">Kategori Kebudayaan</a>
                <ul class="dropdown">
                    <?php
                    if (mysqli_num_rows($resultKategori) > 0) {
                        while ($data = mysqli_fetch_assoc($resultKategori)) {
                            echo "<li><a href='kategori.php?id=$data[id]'>" . $data['nama'] . "</a></li>";
                        }
                    }
                    ?>
                </ul>
            </li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="logout.php">Log Out</a></li>
        </ul>
    </nav>
    <?php while ($data = mysqli_fetch_assoc($resultUser)) {
        echo '<h2 id="welcome">
        Selamat Datang di Kunjungan Kebudayaan Sulawesi Selatan,<br>' . $data['username'] .
            '<p class="teks"><br>Menurut catatan sejarah, cikal bakal lahirnya Kota Makassar berawal dari 1 April 1906. Kawasan ini yang berkembang menjadi kota Makassar hingga kini disebut hari kebudayaan makassar, sebelumnya merupakan hari jadi Kotamadya Ujung Pandang.
            <br><br><a href="profil.php">Cek Profil >>></a>
        </p>
    </h2>';
    } ?>
    <?php
    for ($i = 1; $i <= mysqli_num_rows($resultKategori); $i++) {
        echo "<div class='homeList'>";
        $queryKategori1 = "SELECT * FROM kategori WHERE id=$i";
        $resultKategori1 = mysqli_query($con, $queryKategori1);

        if (mysqli_num_rows($resultKategori1) == 1) {
            while ($data = mysqli_fetch_assoc($resultKategori1)) {
                echo "<div id='judul'>" . $data['nama'] . "</div>";
            }
        }
        $queryTampil1 = "SELECT * FROM budaya WHERE id_kategori=$i ORDER by id DESC LIMIT 1";
        $resultTampil1 = mysqli_query($con, $queryTampil1);

        if (mysqli_num_rows($resultTampil1) == 1) {
            while ($data = mysqli_fetch_assoc($resultTampil1)) {
                echo "
                            <img src='" . $data['gambar'] . "'>
                            <a id='nama' href='detail.php?id=$data[id]'>" . $data['nama'] . "</a>
                            <a id='see' href='kategori.php?id=$i'>See More >>></a>";
            }
        }
        echo "</div>";
    }
    ?>
 
</body>

</html>