<?php
require("session.php");
require("koneksi.php");
$id = $_GET['id'];

$queryKategori = "SELECT * FROM kategori";
$resultKategori = mysqli_query($con,$queryKategori);

$queryInsert = "SELECT * FROM budaya WHERE id=$id";
$result = mysqli_query($con,$queryInsert);
$data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Profil</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 720px;
        }
    </style>
</head>
<body class="container">
        <nav>
            <div class="brand">
                <h3><a href="home.php">Web Budaya</a></h3>
            </div>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li>
                    <a href="">Kategori Kebudayaan</a>
                    <ul class="dropdown">
                        <?php
                            if (mysqli_num_rows($resultKategori) > 0) {
                                while($kategori = mysqli_fetch_assoc($resultKategori)) {
                                    echo "<li><a href='kategori.php?id=$kategori[id]'>".$kategori['nama']."</a></li>";
                                }
                            }
                        ?>
                    </ul>
                </li>
                <li><a href="profil.php">Profil</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </nav>
        <div class="detailJudul"></div>
        <div class="detailFoto">
            <?php
                echo '<img src="'.$data['gambar'].'">';
            ?>
        </div>
        <div class="detailDesk">
            <?php
                echo "<h4>".$data['nama']."</h4>";
                echo "<p>".$data['deskripsi']."</p>";
            ?>
        </div>
       
</body>
</html>