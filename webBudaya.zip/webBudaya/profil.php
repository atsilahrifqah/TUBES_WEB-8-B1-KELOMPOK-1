<?php 
require("session.php");
require("koneksi.php");

$queryKategori = "SELECT * FROM kategori";
$resultKategori = mysqli_query($con,$queryKategori);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Profil</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 1100px;
        }
    </style>
</head>
<body class="container">
        <nav>
            <div class="brand">
                <h3><a href="home.php">Web Budaya</a></h3>
            </div>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li>
                    <a href="">Kategori Kebudayaan</a>
                    <ul class="dropdown">
                        <?php
                            if (mysqli_num_rows($resultKategori) > 0) {
                                while($data = mysqli_fetch_assoc($resultKategori)) {
                                    echo "<li><a href='kategori.php?id=$data[id]'>".$data['nama']."</a></li>";
                                }
                            }
                        ?>
                    </ul>
                </li>
                <li><a href="profil.php">Profil</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </nav>
        <div class="detailJudul">Tentang Kota Makassar</div>
        <div class="detailFoto">
            <img src="logomks.jpg">
            <img src="citylightmks.jpg">
        </div>
        <div class="detailDesk">
            <p>
            Menurut catatan sejarah, cikal bakal lahirnya Kota Makassar berawal dari 1 April 1906. Saat itu pemerintah Hindia Belanda membentuk dewan pemerintahan Gemeentee di Kampung Baru, yang terletak di kawasan Pantai Losari dan Benteng Fort Rotterdam. Kawasan ini yang berkembang menjadi kota Makassar hingga kini disebut hari kebudayaan makassar, sebelumnya merupakan hari jadi Kotamadya Ujung Pandang.
Nama Makassar sendiri sempat diganti menjadi Ujung Pandang di masa pemerintahan Orde Baru, tepatnya pada 31 Agustus 1971. Meski begitu, sebutan Ujung Pandang sudah dikenal sejak tahun 1950-an.
Usaha perluasan wilayah pemerintahan Kotamadya Makassar akhirnya berhasil dapat diwujudkan pada tahun 1971, dari luas wilayah 21 km² menjadi 175 km² berdasarkan Peraturan Pemerintah Nomor 51 Tahun 1971 tanggal 1 September 1971. Perluasan wilayah ini diikuti pula dengan perubahan nama Kotamadya Makassar menjadi Kotamadya Ujung Pandang.
Perlu diketahui bahwa perubahan nama Kotamadya, Makassar menjadi Kotamadya Ujung Pandang yang berdasarkan Peraturan Pemerintah Nomor 51 Tahun 1971 itu, sesungguhnya pada tahun 1964 oleh Dewan Perwakilan Rakyat Daerah Gotong Royong Kotapraja Makassar telah disetujui pergantian nama Kotapraja Makassar menjadi Kotapraja Ujung Pandang yang dituangkan dalam Surat Keputusan Dewan Perwakilan Rakyat Daerah Gotong Royong Kotapraja Makassar Nomor 29/DPRD-GR tanggal 24 September 1964.
Nama Kota Ujung Pandang yang diresmikan pemakaiannya pada tanggal 14 September 1971, berdasarkan Peraturan Pemerintah RI Nomor 51 Tahun 1971 yang dinyatakan berlaku tanggal 1 September 1971, merupakan perubahan nama dari Kota Makassar yang telah diperluas.
Dengan perubahan nama Makassar menjadi Ujung Pandang telah mendapat tanggapan dari berbagai tokoh tokoh masyarakat di Sulawesi Selatan. Salah satu tanggapan mengenai pengembalian nama Makassar, pada tanggal 17 Juli 1976 diajukan petisi yang ditandatangani oleh Prof. Dr. A. Zainal Abidin Farid S. H., Dr. Mattulada, dan Drs. H. Dg Mangemba, tiga budayawan terkemuka Makassar menuntut pengembalian nama Makassar. Usaha-usaha pengembalian nama Makassar terus bergulir, pada tanggal 21 Agustus 1995, Walikotamadya Ujung Pandang, H. Malik B. Masry, SE, MS mengadakan seminar yang hasil rekomendasi untuk pengembalian nama Kota Makassar.
Selanjutnya pada tanggal 21 Agustus 1999 diterbitkan Keputusan Pimpinan Dewan perwakilan Rakyat Daerah Kotamadya Ujung Pandang Nomor 05/Pim/DPRD/VIII/1999 yang memuat persetujuan DPRD Kotamadya Ujung Pandang atas rencana perubahan nama Ujung Pandang menjadi Makassar yang diusulkan oleh Walikota Drs. H. Baso Amiruddin Maula, S.H, M.Si. Akhirnya pada tanggal 13 Oktober 1999, diterbitkan Peraturan Pemerintah Nomor 86 Tahun 1999 yang menetapkan pengembalian nama Kotamadya Ujung Pandang menjadi Kota Makassar dalam wilayah Provinsi Sulawesi Selatan</p>
        </div>
       
</body>
</html>