<?php
$server = "localhost";
$user = "root";
$pwd = "";
$database ="budaya";

$con = mysqli_connect($server,$user,$pwd,$database);
?>