<?php
require('session.php');
require('koneksi.php');
$idKategori = $_GET['id'];

$queryDropdown = "SELECT * FROM kategori";
$resultDropdown = mysqli_query($con, $queryDropdown);

$queryKategori = "SELECT * FROM kategori WHERE id=$idKategori";
$resultKategori = mysqli_query($con, $queryKategori);

$queryBudaya = "SELECT * FROM budaya WHERE id_kategori=$idKategori";
$resultBudaya = mysqli_query($con, $queryBudaya);

if(isset ($_POST["search"])) {
    $keyword = $_POST["keyword"];
    echo "<div class='teksCari'>Menampilkan hasil pencarian untuk keyword '".$keyword."' : </div>";
    $querySearch = "SELECT * FROM budaya WHERE id_kategori=$idKategori AND nama LIKE '%$keyword%'";
    $resultBudaya = mysqli_query($con, $querySearch);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Kebudayaan</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 720px;
            overflow: auto;
        }
    </style>
</head>
<body class="container">
    <nav>
        <div class="brand">
            <h3><a href="home.php">Web Budaya</a></h3>
        </div>
        <form action="" method="post">
            <input id="keyword" name="keyword" type="text" placeholder="search here..." size="15" autocomplete="off">
            <input id="search" name="search" type="submit">
        </form>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li>
                <a href="">Kategori Kebudayaan</a>
                <ul class="dropdown">
                        <?php
                            if (mysqli_num_rows($resultDropdown) > 0) {
                                while($data = mysqli_fetch_assoc($resultDropdown)) {
                                    echo "<li><a href='kategori.php?id=$data[id]'>".$data['nama']."</a></li>";
                                }
                            }
                        ?>
                </ul>
            </li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="logout.php">Log Out</a></li>
        </ul>
    </nav>
    <?php
        if (mysqli_num_rows($resultKategori) > 0) {
            while($data = mysqli_fetch_assoc($resultKategori)) {
                echo "<p class='kategori'>".$data['nama']."</p>";
            }
        }
    ?>
    <div class="budaya">
        <?php
           if(mysqli_num_rows($resultBudaya) > 0) {
            while($data = mysqli_fetch_assoc($resultBudaya)) {
                echo '<div class="listBudaya">';
                echo "<a href='detail.php?id=$data[id]'>".$data["nama"]."</a>";
                echo '<img src="'.$data["gambar"].'">';
                echo '</div>';

                echo "<script>
                    const img=document.getElementsByTagName('img')[0];
                    img.addEventListener('click',function(){
                        window.location.href='detail.php?db=ikon &id=$data[id]';
                    })
                </script>";
            }
        } 
        ?>
    </div>
    
</body>
</html>