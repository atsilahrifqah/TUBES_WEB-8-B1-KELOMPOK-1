<?php
    require("koneksi.php");

    $id = $_GET['id'];
    $queryDelete = "DELETE FROM budaya WHERE id=$id";
    $delete = mysqli_query($con,$queryDelete);

    if ($delete) {
        header("location:http://localhost/webbudaya/hapus.php");
    }
?>