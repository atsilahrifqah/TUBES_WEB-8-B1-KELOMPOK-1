<?php
require('koneksi.php');

function regist($data) {
    global $con;

    $username = strtoupper($data["username"]);
    $password = $data["password"];
    $password2 = $data["password2"];

    //cek konfirmasi password
    if ($password !== $password2) {
        echo '<script>
                alert("konfirmasi tidak sesuai");
            </script>';
        return false;
    } 

    //cek username
    $queryUsername = "SELECT username FROM users WHERE username = '$username'";
    $result = mysqli_query($con, $queryUsername);
    if (mysqli_fetch_assoc($result)) {
        echo '<script>
                alert("username telah terdaftar");
            </script>';
        return false;
    }

    //enkripsi password
    $password = password_hash($password, PASSWORD_DEFAULT);

    //tambah user ke database
    $queryInsert = "INSERT INTO users VALUES('','$username','$password')";
    mysqli_query($con, $queryInsert);
    
    return mysqli_affected_rows($con);

}
