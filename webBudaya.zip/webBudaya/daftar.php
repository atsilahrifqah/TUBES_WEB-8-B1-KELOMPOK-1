<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Budaya - Registrasi</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <style>
        .container{
            height: 720px;
        }
        #welcome{
            top: 150px;
            color: white;
        }
    </style>
</head>
<body class="container">
    <nav>
        <div class="brand">
            <h3><a href="home.php">Web Budaya</a></h3>
        </div>
        <ul>
            <li><a href="login.php">Login</a></li>
            <li><a href="daftar.php">Daftar</a></li>
        </ul>
    </nav>
    <h2 id="welcome">Registrasi Akun</h2>
    <table class="login" align="center" cellspacing="11">
        <form action="" method="post">
            <tr>
                <td>Username</td>
                <td><input type="text" name="username" placeholder="masukkan username" autocomplete="off" required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" placeholder="masukkan password" autocomplete="off" required></td>
            </tr>
            <tr>
                <td>Konfirmasi Password</td>
                <td><input type="password" name="password2" placeholder="masukkan ulang password" autocomplete="off" required></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" name="daftar" value="Daftar" style="cursor: pointer;">
                </td>
            </tr>
        </form>
    </table>
    <!-- <p id='errorRegist'>Username telah terdaftar</p> -->
   
</body>
</html>
<?php
require("regist.php");
if (isset($_POST["daftar"])) {
        if (regist($_POST) > 0) {
            echo '<script>
                alert("user baru ditambahkan");
                </script>';
            header("location:http://localhost/webbudaya/login.php");
        } 
        else {
            mysqli_error($con);
        }
    }
?>